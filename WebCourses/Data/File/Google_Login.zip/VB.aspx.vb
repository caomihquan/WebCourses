﻿Imports ASPSnippets.GoogleAPI
Imports System.Web.Script.Serialization

Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        GoogleConnect.ClientId = "<Google Client ID>"
        GoogleConnect.ClientSecret = "<Google Client Secret>"
        GoogleConnect.RedirectUri = Request.Url.AbsoluteUri.Split("?"c)(0)

        If Not IsPostBack Then
            If Not String.IsNullOrEmpty(Request.QueryString("code")) Then
                Dim code As String = Request.QueryString("code")
                Dim json As String = GoogleConnect.Fetch("me", code)
                Dim profile As GoogleProfile = New JavaScriptSerializer().Deserialize(Of GoogleProfile)(json)
                lblId.Text = profile.Id
                lblName.Text = profile.Name
                lblEmail.Text = profile.Email
                lblVerified.Text = profile.verified_Email
                ProfileImage.ImageUrl = profile.Picture
                pnlProfile.Visible = True
                btnLogin.Enabled = False
            End If
            If Request.QueryString("error") = "access_denied" Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "alert", "alert('Access denied.')", True)
            End If
        End If
    End Sub

    Protected Sub Login(sender As Object, e As EventArgs)
        GoogleConnect.Authorize("profile", "email")
    End Sub
    Protected Sub Clear(sender As Object, e As EventArgs)
        GoogleConnect.Clear(Request.QueryString("code"))
    End Sub

    Public Class GoogleProfile
        Public Property Id() As String
        Public Property Name() As String
        Public Property Picture() As String
        Public Property Email() As String
        Public Property verified_Email() As String
    End Class
End Class
